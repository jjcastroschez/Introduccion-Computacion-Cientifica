"""Submódulos: enteros."""
