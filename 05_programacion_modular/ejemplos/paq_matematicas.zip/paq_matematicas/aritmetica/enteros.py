"""Funciones de aritmética entera: MCD, MCM, primos."""


def mcd(a: int, b: int) -> int:
    """Algoritmo de Euclides."""
    while b != 0:
        a, b = b, a % b
    return a


def mcm(a: int, b: int) -> int:
    """Mínimo común múltiplo."""
    return abs(a * b) // mcd(a, b)


def es_primo(n: int) -> bool:
    """Test de primalidad por divisiones sucesivas."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i = i + 2
    return True
